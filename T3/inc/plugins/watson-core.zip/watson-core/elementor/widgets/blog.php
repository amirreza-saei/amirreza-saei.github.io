<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson Blog Widget.
 *
 * @since 1.0
 */
class Watson_Blog_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-blog';
    }

    public function get_title()
    {
        return esc_html__('Blog', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-single-post';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'items_tab',
            [
                'label' => esc_html__('Items', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'source',
            [
                'label'       => esc_html__('Source', 'watson'),
                'type'        => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all'  => __('All', 'watson'),
                    'categories' => __('Categories', 'watson'),
                ],
            ]
        );

        $this->add_control(
            'source_categories',
            [
                'label'       => esc_html__('Source', 'watson'),
                'type'        => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_blog_categories(),
                'condition' => [
                    'source' => 'categories'
                ],
            ]
        );

        $this->add_control(
            'limit',
            [
                'label'       => esc_html__('Number of Items', 'watson'),
                'type'        => Controls_Manager::NUMBER,
                'placeholder' => 9,
                'default'     => 9,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'pagination_tab',
            [
                'label' => esc_html__('Pagination', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'pagination',
            [
                'label'       => esc_html__('Pagination Type', 'watson'),
                'type'        => Controls_Manager::SELECT,
                'default' => 1,
                'options' => [
                    '1' => __('Pagination', 'watson'),
                    '2' => __('Button', 'watson'),
                    '0' => __('No', 'watson'),
                ],
            ]
        );

        $this->add_control(
            'more_btn_txt',
            [
                'label'       => esc_html__('Button (title)', 'watson'),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => esc_html__('Enter button', 'watson'),
                'default'     => esc_html__('All Posts', 'watson'),
                'condition' => [
                    'pagination' => '2'
                ],
            ]
        );

        $this->add_control(
            'more_btn_link',
            [
                'label'       => esc_html__('Button (link)', 'watson'),
                'type'        => Controls_Manager::URL,
                'show_external' => true,
                'condition' => [
                    'pagination' => '2'
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'items_styling',
            [
                'label'     => esc_html__('Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_cat_color',
            [
                'label'     => esc_html__('Category Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .categories' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_cat_typography',
                'label'     => esc_html__('Category Typography', 'watson'),
                'selector' => '{{WRAPPER}} .blog-item .blog-content .categories',
            ]
        );

        $this->add_control(
            'item_title_color',
            [
                'label'     => esc_html__('Title Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_title_typography',
                'label'     => esc_html__('Title Typography', 'watson'),
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-title',
            ]
        );

        $this->add_control(
            'item_date_color',
            [
                'label'     => esc_html__('Date Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-date' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_date_typography',
                'label'     => esc_html__('Date Typography', 'watson'),
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-date',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render Categories List.
     *
     * @since 1.0
     */
    protected function get_blog_categories()
    {
        $categories = [];

        $args = array(
            'type'            => 'post',
            'child_of'        => 0,
            'parent'        => '',
            'orderby'        => 'name',
            'order'            => 'DESC',
            'hide_empty'    => 1,
            'hierarchical'    => 1,
            'taxonomy'        => 'category',
            'pad_counts'    => false
        );

        $blog_categories = get_categories($args);

        foreach ($blog_categories as $category) {
            $categories[$category->term_id] = $category->name;
        }

        return $categories;
    }

    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $blog_slug = '#' . get_post_field('post_name', get_post());

        if ($settings['limit']) {
            $posts_per_page = $settings['limit'];
        } else {
            $posts_per_page = get_option('posts_per_page');
        }

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        if ($settings['source'] == 'all') {
            $cat_ids = '';
        } else {
            $cat_ids = $settings['source_categories'];
        }

        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_status' => 'publish',
            'order' => 'desc'
        );

        if ($settings['source'] == 'categories') {
            $args['cat'] = $cat_ids;
        }

        $q = new \WP_Query($args);

?>

        <?php if ($q->have_posts()) : ?>
            <div class="blog-list">
                <div class="row blogs-masonry">
                    <?php while ($q->have_posts()) : $q->the_post(); ?>

                        <?php get_template_part('sections/blog_list_section'); ?>

                    <?php endwhile; ?>
                </div>
            </div>

            <?php if ($settings['pagination'] == '1') : ?>
                <div class="blog-navigation">
                    <?php
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links(array(
                        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                        'format' => '?paged=%#%',
                        'type'  => 'list',
                        'current' => max(1, $paged),
                        'total' => $q->max_num_pages,
                        'prev_text' => esc_html__('Prev', 'watson'),
                        'next_text' => esc_html__('Next', 'watson'),
                        'show_all'     => false,
                        'end_size'     => 1,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'add_args'     => false,
                        'add_fragment' => $blog_slug,
                    ));
                    ?>
                </div>
            <?php endif; ?>
            <?php if ($settings['pagination'] == '2' && $settings['more_btn_link']) : ?>
                <div class="blog-button text-center">
                    <a class="btn-main" href="<?php echo esc_url($settings['more_btn_link']['url']); ?>" <?php if ($settings['more_btn_link']['is_external']) : ?> target="_blank" <?php endif; ?><?php if ($settings['more_btn_link']['nofollow']) : ?> rel="nofollow" <?php endif; ?>><?php echo esc_html($settings['more_btn_txt']); ?></a>
                </div>
            <?php endif; ?>
        <?php else : ?>

            <h2><?php esc_html_e('Nothing Found', 'watson') ?></h2>
            <p><?php esc_html_e('It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'watson'); ?></p>
            <?php get_search_form(); ?>

        <?php endif;

        if(is_admin()) {
	        echo "<script>
	            if ($('.blogs-masonry').length) {
	                var macy = Macy({
	                    container: '.blogs-masonry',
	                    trueOrder: false,
	                    waitForImages: false,
	                    margin: 0,
	                    columns: 3,
	                    breakAt: {
	                        980: 2,
	                        575: 1,
	                    }
	                });

	                setTimeout(function() {
	                    macy.reInit();
	                }, 10);
	            }
	        </script>";
    	}

wp_reset_postdata();
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Blog_Widget());
