<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * RyanCV Skills Widget.
 *
 * @since 1.0
 */

class Watson_Resume_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-resume';
    }

    public function get_title()
    {
        return esc_html__('Resume', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-site-identity';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'heading_tab',
            [
                'label' => esc_html__('Title', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Content', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'year_till', [
                'label'       => esc_html__('Year Till', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter year till', 'watson'),
                'default' => esc_html__('Enter year till', 'watson'),
            ]
        );

        $repeater->add_control(
            'year_from', [
                'label'       => esc_html__('Year From', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter year from', 'watson'),
                'default' => esc_html__('Enter year from', 'watson'),
            ]
        );

        $repeater->add_control(
            'title', [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter title', 'watson'),
                'default' => esc_html__('Enter title', 'watson'),
            ]
        );

        $repeater->add_control(
            'subtitle', [
                'label'       => esc_html__('SubTitle', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter subtitle', 'watson'),
                'default' => esc_html__('Enter subtitle', 'watson'),
            ]
        );

        $repeater->add_control(
            'text', [
                'label'       => esc_html__('Text', 'watson'),
                'type'        => Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__('Enter text', 'watson'),
                'default' => esc_html__('Enter text', 'watson'),
            ]
        );
        
        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .resume .subheading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .resume .subheading',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_styling',
            [
                'label' => esc_html__('Items', 'watson'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_date_color',
            [
                'label' => esc_html__('Year Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .resume .timeline .year .to' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .resume .timeline .year .from' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_year_typography',
                'label' => esc_html__('Year Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .resume .timeline .year',
            ]
        );

        $this->add_control(
            'items_title_color',
            [
                'label' => esc_html__('Title Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .resume .timeline .content .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_title_typography',
                'label' => esc_html__('Title Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .resume .timeline .content .title',
            ]
        );

        $this->add_control(
            'items_subtitle_color',
            [
                'label' => esc_html__('Subtitle Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .resume .timeline .content .subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_subtitle_typography',
                'label' => esc_html__('Subtitle Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .resume .timeline .content .subtitle',
            ]
        );

        $this->add_control(
            'items_text_color',
            [
                'label' => esc_html__('Text Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .resume .timeline .content .info' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_text_typography',
                'label' => esc_html__('Text Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .resume .timeline .content .info',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $this->add_inline_editing_attributes('title', 'basic');
?>

        <div class="resume">

            <?php if ($settings['title']) : ?>
                <h3 class="subheading">
                    <span <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></span>
                </h3>
            <?php endif; ?>

            <?php if ($settings['items']) : ?>
                <ul class="timeline">

                    <?php foreach ($settings['items'] as $index => $item) :
                        $item_year_from = $this->get_repeater_setting_key('year_from', 'items', $index);
                        $this->add_inline_editing_attributes($item_year_from, 'basic');
                        $item_year_till = $this->get_repeater_setting_key('year_till', 'items', $index);
                        $this->add_inline_editing_attributes($item_year_till, 'basic');
                        $item_title = $this->get_repeater_setting_key('title', 'items', $index);
                        $this->add_inline_editing_attributes($item_title, 'basic');
                        $item_subtitle = $this->get_repeater_setting_key('subtitle', 'items', $index);
                        $this->add_inline_editing_attributes($item_subtitle, 'basic');
                        $item_text = $this->get_repeater_setting_key('text', 'items', $index);
                        $this->add_inline_editing_attributes($item_text, 'advanced');
                    ?>
                        <li>
                            <span class="line-left"></span>
                            <div class="year">
                                <?php if ($item['year_till']) : ?>
                                    <span class="to">
                                        <span <?php echo $this->get_render_attribute_string($item_year_till); ?>>
                                            <?php echo wp_kses_post($item['year_till']); ?>
                                        </span>
                                    </span>
                                <?php endif; ?>

                                <?php if ($item['year_from']) : ?>
                                    <span class="from">
                                        <span <?php echo $this->get_render_attribute_string($item_year_from); ?>>
                                            <?php echo wp_kses_post($item['year_from']); ?>
                                        </span>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="content">

                                <?php if ($item['title']) : ?>
                                    <h4 class="title">
                                        <span <?php echo $this->get_render_attribute_string($item_title); ?>>
                                            <?php echo wp_kses_post($item['title']); ?>
                                        </span>
                                    </h4>
                                <?php endif; ?>

                                <?php if ($item['subtitle']) : ?>
                                    <h5 class="subtitle">
                                        <span <?php echo $this->get_render_attribute_string($item_subtitle); ?>>
                                            <?php echo wp_kses_post($item['subtitle']); ?>
                                        </span>
                                    </h5>
                                <?php endif; ?>

                                <?php if ($item['text']) : ?>
                                    <div class="info">
                                        <div <?php echo $this->get_render_attribute_string($item_text); ?>>
                                            <?php echo wp_kses_post($item['text']); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

    <?php


    }

    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    {
    ?>
        <# view.addInlineEditingAttributes( 'title' , 'basic' ); #>

            <div class="resume">

                <# if ( settings.title ) { #>
                    <h3 class="subheading">
                        <span {{{ view.getRenderAttributeString('title') }}} >
                            {{{ settings.title }}}
                        </span>
                    </h3>
                <# } #>

                <# if ( settings.items ) { #>
                    <ul class="timeline">

                        <# _.each( settings.items, function( item, index ) {

                        var item_year_from = view.getRepeaterSettingKey( 'year_from', 'items', index );
                        view.addInlineEditingAttributes( item_year_from, 'basic' );
                        var item_year_till = view.getRepeaterSettingKey( 'year_till', 'items', index );
                        view.addInlineEditingAttributes( item_year_till, 'basic' );
                        var item_title = view.getRepeaterSettingKey( 'title', 'items', index );
                        view.addInlineEditingAttributes( item_title, 'basic' );
                        var item_subtitle = view.getRepeaterSettingKey( 'subtitle', 'items', index );
                        view.addInlineEditingAttributes( item_subtitle, 'basic' );
                        var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
                        view.addInlineEditingAttributes( item_text, 'advanced' );

                        #>
                            <li>
                                <span class="line-left"></span>
                                <div class="year">
                                    <# if ( item.year_till ) { #>
                                        <span class="to">
                                            <span {{{ view.getRenderAttributeString( item.year_till ) }}} >
                                                {{{ item.year_till }}}
                                            </span>
                                        </span>
                                    <# } #>

                                    <# if ( item.year_from ) { #>
                                        <span class="from">
                                            <span {{{ view.getRenderAttributeString( item_year_from ) }}} >
                                                {{{ item.year_from }}}
                                            </span>
                                        </span>
                                    <# } #>
                                </div>
                                <div class="content">

                                    <# if ( item.title ) { #>
                                        <h4 class="title">
                                            <span {{{ view.getRenderAttributeString( item_title ) }}} >
                                                {{{ item.title }}}
                                            </span>
                                        </h4>
                                    <# } #>

                                    <# if ( item.subtitle ) { #>
                                        <h5 class="subtitle">
                                            <span {{{ view.getRenderAttributeString( item_subtitle ) }}}>
                                                {{{ item.subtitle }}}
                                            </span>
                                        </h5>
                                    <# } #>

                                    <# if ( item.text ) { #>
                                        <div class="info">
                                            <div {{{ view.getRenderAttributeString( item_text ) }}}>
                                                {{{ item.text }}}
                                            </div>
                                        </div>
                                    <# } #>

                                </div>
                            </li>
                        <# }); #>
                    </ul>
                <# } #>
            </div>


    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Resume_Widget());
