<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson Portfolio Widget.
 *
 * @since 1.0
 */
class Watson_Portfolio_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-portfolio';
    }

    public function get_title()
    {
        return esc_html__('Portfolio', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-library-save';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'filters_tab',
            [
                'label' => esc_html__('Filters', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'filters',
            [
                'label' => esc_html__('Show Filters', 'watson'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'watson'),
                'label_off' => __('Hide', 'watson'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_tab',
            [
                'label' => esc_html__('Items', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'source',
            [
                'label'       => esc_html__('Source', 'watson'),
                'type'        => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all'  => __('All', 'watson'),
                    'categories' => __('Categories', 'watson'),
                ],
            ]
        );

        $this->add_control(
            'source_categories',
            [
                'label'       => esc_html__('Source', 'watson'),
                'type'        => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_portfolio_categories(),
                'condition' => [
                    'source' => 'categories'
                ],
            ]
        );

        $this->add_control(
            'limit',
            [
                'label'       => esc_html__('Number of Items', 'watson'),
                'type'        => Controls_Manager::NUMBER,
                'placeholder' => 8,
                'default'     => 8,
            ]
        );

        $this->add_control(
            'sort',
            [
                'label'       => esc_html__('Sorting By', 'watson'),
                'type'        => Controls_Manager::SELECT,
                'default' => 'menu_order',
                'options' => [
                    'date'  => __('Date', 'watson'),
                    'title' => __('Title', 'watson'),
                    'rand' => __('Random', 'watson'),
                    'menu_order' => __('Order', 'watson'),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label'       => esc_html__('Order', 'watson'),
                'type'        => Controls_Manager::SELECT,
                'default' => 'asc',
                'options' => [
                    'asc'  => __('ASC', 'watson'),
                    'desc' => __('DESC', 'watson'),
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'items_styling',
            [
                'label'     => esc_html__('Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_icon_color',
            [
                'label'     => esc_html__('Icon Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .portfolio-item a figure:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_title_color',
            [
                'label'     => esc_html__('Title Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .portfolio-item figure figcaption h4' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_title_typography',
                'label'     => esc_html__('Title Typography', 'watson'),
                'selector' => '{{WRAPPER}} .portfolio-item figure figcaption h4',
            ]
        );

        $this->add_control(
            'item_category_color',
            [
                'label'     => esc_html__('Category Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .portfolio-item figure figcaption p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_category_typography',
                'label'     => esc_html__('Category Typography', 'watson'),
                'selector' => '{{WRAPPER}} .portfolio-item figure figcaption p',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render Categories List.
     *
     * @since 1.0
     */
    protected function get_portfolio_categories()
    {
        $categories = [];

        $args = array(
            'type'            => 'post',
            'child_of'        => 0,
            'parent'        => '',
            'orderby'        => 'name',
            'order'            => 'DESC',
            'hide_empty'    => 1,
            'hierarchical'    => 1,
            'taxonomy'        => 'portfolio_category',
            'pad_counts'    => false
        );

        $portfolio_categories = get_categories($args);

        foreach ($portfolio_categories as $category) {
            $categories[$category->term_id] = $category->name;
        }

        return $categories;
    }

    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if ($settings['source'] == 'all') {
            $cat_ids = '';
        } else {
            $cat_ids = $settings['source_categories'];
        }

        $cat_args = array(
            'type' => 'post',
            'child_of'        => 0,
            'parent'        => '',
            'orderby'        => 'name',
            'order'            => 'DESC',
            'hide_empty'    => 1,
            'hierarchical'    => 1,
            'taxonomy'        => 'portfolio_category',
            'pad_counts'    => false,
            'include'        => $cat_ids,
        );

        $pf_categories = get_categories($cat_args);

        $args = array(
            'post_type'            => 'portfolio',
            'post_status'        => 'publish',
            'orderby'            => $settings['sort'],
            'order'                => $settings['order'],
            'posts_per_page'    => $settings['limit']
        );

        if ($settings['source'] == 'categories') {
            $tax_array = array(
                array(
                    'taxonomy' => 'portfolio_category',
                    'field'    => 'id',
                    'terms'    => $cat_ids
                )
            );

            $args += array('tax_query' => $tax_array);
        }

        $q = new \WP_Query($args);

?>

        <div class="portfolio">
            <div class="row">
                <?php if ($settings['filters'] && $pf_categories) : ?>
                    <div class="col-md-12 portfolio-filter text-center">
                        <ul>
                            <li class="active" data-filter="*"><?php esc_html_e('All', 'watson'); ?></li>

                            <?php foreach ($pf_categories as $category) : ?>
                                <li data-filter=".f-<?php echo esc_attr($category->slug); ?>">
                                    <?php echo esc_html($category->name); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($q->have_posts()) : ?>
                <div class="row portfolio-items">
                    <?php while ($q->have_posts()) : $q->the_post();

                        $current_categories = get_the_terms(get_the_ID(), 'portfolio_category');
                        $category = '';
                        $category_slug = '';
                        if ($current_categories && !is_wp_error($current_categories)) {
                            $arr_keys = array_keys($current_categories);
                            $last_key = end($arr_keys);
                            foreach ($current_categories as $key => $value) {
                                if ($key == $last_key) {
                                    $category .= $value->name;
                                } else {
                                    $category .= $value->name . ', ';
                                }
                                $category_slug .= 'f-' . $value->slug . ' ';
                            }
                        }

                        $id = get_the_ID();
                        $title = get_the_title();
                        $href = get_the_permalink();
                        $p_single = watson_get_theme_options('ct_watson_portfolio_single_page_enable');
                        $link_target = false;

                        $p_type = watson_get_post_meta($id, 'watson_portfolio_option_portfolio_type');

                        switch ($p_type) {
                            case 'video':
                                $p_url = watson_get_post_meta($id, 'watson_portfolio_option_radio_button_video_url');
                                break;
                            case 'music':
                                $p_url = watson_get_post_meta($id, 'watson_portfolio_option_radio_button_music_url');
                                break;
                            case 'link':
                                $p_url = watson_get_post_meta($id, 'watson_portfolio_option_radio_button_link_url');
                                $link_target = true;
                                break;
                            case 'ajax':
                                $p_url = $href;
                                break;
                            case 'image':
                                $p_url = get_the_post_thumbnail_url($id);
                                break;
                        }


                    ?>
                        <!--Portfolio Item-->
                        <div class="portfolio-item col-lg-4 col-sm-6 <?php echo esc_attr($category_slug); ?>">


                            <?php if ($p_single) : ?>

                                <a class="book-icon" href="<?php echo esc_attr($href); ?>">

                            <?php else : ?>

                                <a class="<?php echo esc_attr($p_type) ?>-icon <?php echo esc_attr($p_type); ?>-link" href="<?php echo esc_attr($p_url); ?>" <?php if ($link_target) : ?> target="_blank" <?php endif; ?>>

                            <?php endif; ?>
                                    <figure>
                                        <?php if (has_post_thumbnail($id)) :
                                            echo get_the_post_thumbnail($id);
                                        else : ?>
                                            <div class="portfolio-no-image"></div>
                                        <?php endif; ?>
                                        <figcaption>
                                            <?php if ($title) : ?>
                                                <h4><?php echo esc_html($title); ?></h4>
                                            <?php endif; ?>

                                            <?php if ($category) : ?>
                                                <p><?php echo esc_html($category); ?></p>
                                            <?php endif; ?>
                                        </figcaption>
                                    </figure>

                                </a>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>

        </div>

<?php
        if (is_admin()) {
            echo "<script>
                if( $('.portfolio-items').length ) {
                    $('.portfolio-items').isotope();
                }
            </script>";
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Portfolio_Widget());
