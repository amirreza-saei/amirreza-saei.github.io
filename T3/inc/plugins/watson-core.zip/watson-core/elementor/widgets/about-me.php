<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson About Me Widget.
 *
 * @since 1.0
 */
class Watson_About_Me_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-about-me';
    }

    public function get_title()
    {
        return esc_html__('About Me', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-info';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'desc_tab',
            [
                'label' => esc_html__('Personal Description', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'desc_title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->add_control(
            'desc_content',
            [
                'label'       => esc_html__('Description', 'watson'),
                'type'        => Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__('Enter description',   'watson'),
                'default'     => esc_html__('Enter description', 'watson'),
            ]
        );


        $this->add_control(
            'show_sign',
            [
                'label'        => esc_html__('Show Signature', 'watson'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'watson'),
                'label_off'    => esc_html__('Hide', 'watson'),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
            'desc_sign',
            [
                'label' => esc_html__('Upload Signature', 'watson'),
                'type'  => Controls_Manager::MEDIA,
                'condition'   => [
                    'show_sign' => 'yes'
                ],
            ],
        );

        $this->add_control(
            'sign_width',
            [
                'label'       => esc_html__('Signature Width in %', 'watson'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 5,
                'default' => 50,
                'condition'   => [
                    'show_sign' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'info_tab',
            [
                'label' => esc_html__('Personal Information', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'info_title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'label',
            [
                'label'       => esc_html__('Label', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter label', 'watson'),
                'default' => esc_html__('Enter label', 'watson'),
            ]
        );

        $repeater->add_control(
            'value',
            [
                'label'       => esc_html__('Value', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter value', 'watson'),
                'default' => esc_html__('Enter value', 'watson'),
            ]
        );

        $this->add_control(
            'info_items',
            [
                'label' => esc_html__('Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ label }}}',
            ]
        );

        $this->add_control(
            'show_resume_btn',
            [
                'label'        => esc_html__('Show Resume Button', 'watson'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'watson'),
                'label_off'    => esc_html__('Hide', 'watson'),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
            'resume_btn_text',
            [
                'label' => esc_html__('Text', 'watson'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Download Resume', 'watson'),
                'condition'   => [
                    'show_resume_btn' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'resume_btn_url',
            [
                'label' => esc_html__('Link', 'watson'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://your-link.com', 'watson'),
                'show_external' => false,
                'default' => [
                    'url' => home_url(),
                    'is_external' => false,
                    'nofollow' => true,
                ],
                'condition'   => [
                    'show_resume_btn' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .about .heading-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .about .heading-title',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'description_styling',
            [
                'label'     => esc_html__('Description', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .about .text-box' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'selector' => '{{WRAPPER}} .about .text-box',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_styling',
            [
                'label'     => esc_html__('Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_label_color',
            [
                'label'     => esc_html__('Label Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .about .about-info ul li .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_label_typography',
                'label'     => esc_html__('Label Typography', 'watson'),
                'selector' => '{{WRAPPER}} .about .about-info ul li .title',
            ]
        );

        $this->add_control(
            'items_value_color',
            [
                'label'     => esc_html__('Value Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .about .about-info ul li .value' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_value_typography',
                'label'     => esc_html__('Value Typography', 'watson'),
                'selector' => '{{WRAPPER}} .about .about-info ul li .value',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'resume_btn_typography',
                'label'     => esc_html__('Resume Button Typography', 'watson'),
                'selector' => '{{WRAPPER}} .about .about-info .resume-button .btn-main',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if ($settings['show_resume_btn'] === "yes") {
            $link_text = esc_html($settings['resume_btn_text']);
            $link_url = esc_url($settings['resume_btn_url']['url']);
            $target = $settings['resume_btn_url']['is_external'] ? ' target="_blank"' : '';
            $nofollow = $settings['resume_btn_url']['nofollow'] ? ' rel="nofollow"' : '';
        }

        $this->add_inline_editing_attributes('desc_title', 'basic');
        $this->add_inline_editing_attributes('desc_content', 'advanced');
        $this->add_inline_editing_attributes('info_title', 'basic');

?>

        <div class="row about">

            <div class="col-lg-8">
                <!--Personal Intro-->
                <?php if ($settings['desc_title']) : ?>
                    <h3 class="heading-title mb-20">
                        <span <?php echo $this->get_render_attribute_string('desc_title') ?>>
                            <?php echo wp_kses_post($settings['desc_title']); ?>
                        </span>
                    </h3>
                <?php endif; ?>

                <?php if ($settings['desc_content']) : ?>
                    <div class="text-box">
                        <div <?php echo $this->get_render_attribute_string('desc_content') ?>>
                            <?php echo wp_kses_post($settings['desc_content']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_sign'] === "yes" && $settings["desc_sign"]["url"]) : ?>
                    <div class="signature mt-20">
                        <img style="width: <?php echo esc_attr($settings['sign_width']) ?>%" src="<?php echo esc_url($settings['desc_sign']['url']); ?>" alt="<?php esc_attr_e('Signature'); ?>">
                    </div>
                <?php endif; ?>

            </div>

            <!--Personal Info-->
            <div class="col-lg-4 about-info-outer">
                <div class="about-info">
                    <?php if ($settings['info_title']) : ?>
                        <h3 class="heading-title mb-20">
                            <span <?php echo $this->get_render_attribute_string('info_title') ?>>
                                <?php echo wp_kses_post($settings['info_title']); ?>
                            </span>
                        </h3>
                    <?php endif; ?>

                    <?php if ($settings['info_items']) : ?>
                        <ul>
                            <?php foreach ($settings['info_items'] as $index => $item) :
                                $item_label = $this->get_repeater_setting_key('label', 'info_items', $index);
                                $this->add_inline_editing_attributes($item_label, 'basic');

                                $item_value = $this->get_repeater_setting_key('value', 'info_items', $index);
                                $this->add_inline_editing_attributes($item_value, 'basic');
                            ?>
                                <li>
                                    <span class="title">
                                        <span <?php echo $this->get_render_attribute_string($item_label); ?>>
                                            <?php echo wp_kses_post($item['label']); ?>
                                        </span>
                                    </span>

                                    <span class="value">
                                        <span <?php echo $this->get_render_attribute_string($item_value); ?>>
                                            <?php echo wp_kses_post($item['value']); ?>
                                        </span>
                                    </span>
                                </li>


                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if ( $settings['show_resume_btn'] === "yes" && $link_url && $link_text) : ?>
                        <div class="resume-button mt-30">
                            <a class="btn-main" href="<?php echo esc_url($link_url); ?>" <?php echo $target . ' ' . $nofollow ?>><?php echo esc_html($link_text); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    <?php
    }

    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    {
    ?>
        <# view.addInlineEditingAttributes( 'desc_title' , 'basic' ); view.addInlineEditingAttributes( 'desc_content' , 'advanced' ); view.addInlineEditingAttributes( 'info_title' , 'basic' ); #>

            <div class="row about">

                <div class="col-lg-8">
                    <!--Personal Intro-->
                    <# if ( settings.desc_title ) { #>
                        <h3 class="heading-title mb-20">
                            <span>
                                {{{ settings.desc_title }}}
                            </span>
                        </h3>
                        <# } #>

                            <# if ( settings.desc_content ) { #>
                                <div class="text-box">
                                    <div {{{ view.getRenderAttributeString( 'desc_content' ) }}}>
                                        {{{ settings.desc_content }}}
                                    </div>
                                </div>
                                <# } #>
                                    <# if ( settings.show_sign === 'yes' && settings.desc_sign.url) { #>
                                        <div class="signature mt-20">
                                            <img style="width: {{{ settings.sign_width }}}%" src="{{{ settings.desc_sign.url }}}" alt="Signature">
                                        </div>
                                        <# } #>

                </div>

                <div class="col-lg-4 about-info-outer">
                    <div class="about-info">
                        <# if ( settings.info_title ) { #>
                            <h3 class="heading-title mb-20">
                                <span {{{ view.getRenderAttributeString( 'info_title' ) }}}>
                                    {{{ settings.info_title }}}
                                </span>
                            </h3>
                            <# } #>

                                <# if ( settings.info_items ) { #>
                                    <ul>
                                        <# _.each( settings.info_items, function( item, index ) { var item_label=view.getRepeaterSettingKey( 'label' , 'info_items' , index ); view.addInlineEditingAttributes( item_label, 'basic' ); var item_value=view.getRepeaterSettingKey( 'value' , 'info_items' , index ); view.addInlineEditingAttributes( item_value, 'basic' ); #>
                                            <li>
                                                <span class="title">
                                                    <span {{{ view.getRenderAttributeString( item_label ) }}}>
                                                        {{{ item.label }}}
                                                    </span>
                                                </span>

                                                <span class="value">
                                                    <span {{{ view.getRenderAttributeString( item_value ) }}}>
                                                        {{{ item.value }}}
                                                    </span>
                                                </span>
                                            </li>


                                            <# }); #>
                                    </ul>
                                    <# } #>
                    <# if ( settings.show_resume_btn === 'yes' && settings.resume_btn_url.url && settings.resume_btn_text) { #>
                        <div class="resume-button mt-30">
                            <a class="btn-main" href="{{{ settings.resume_btn_url.url }}}" >{{{ settings.resume_btn_text }}}</a>
                        </div>
                    <# } #>
                    </div>
                </div>

            </div>

    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_About_Me_Widget());
