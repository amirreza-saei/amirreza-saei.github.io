<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson About Me Widget.
 *
 * @since 1.0
 */
class Watson_Page_Title_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-page-title';
    }

    public function get_title()
    {
        return esc_html__('Page Title', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-header';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Content', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__('Page Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter page title', 'watson'),
                'default'     => esc_html__('Page Title', 'watson'),
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Page Icon', 'watson'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_styling',
            [
                'label'     => esc_html__('Content', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Title Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .page-heading h2' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'     => esc_html__('Title Typography', 'watson'),
                'selector' => '{{WRAPPER}} .page-heading h2',
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .page-heading .icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();
    }


    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $this->add_inline_editing_attributes('title', 'basic');
?>

        <div class="page-heading">
            <?php if ($settings['icon']) : ?>
                <span class="icon">
                    <?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']); ?>
                </span>
            <?php endif; ?>

            <?php if ($settings['title']) : ?>
                <h2 <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></h2>
            <?php endif; ?>

        </div>

    <?php

    }


    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    { ?>
        <# view.addInlineEditingAttributes( 'title' , 'basic' ); var iconHTML=elementor.helpers.renderIcon( view, settings.icon, { 'aria-hidden' : true }, 'i' , 'object' ); #>

            <div class="page-heading">

                <# if ( settings.icon ) { #>
                    <span class="icon">
                        {{{ iconHTML.value }}}
                    </span>
                    <# } #>

                        <# if ( settings.title ) { #>
                            <h2 {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</h2>
                            <# } #>

            </div>

    <?php }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Page_Title_Widget());
