<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * RyanCV Skills Widget.
 *
 * @since 1.0
 */

class Watson_Skills_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-skills';
    }

    public function get_title()
    {
        return esc_html__('Skills', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-star';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'heading_tab',
            [
                'label' => esc_html__('Title', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Content', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // $this->add_control(
        // 	'type',
        // 	[
        // 		'label'       => esc_html__( 'Skills Type', 'ryancv-plugin' ),
        // 		'type'        => Controls_Manager::SELECT,
        // 		'default' => 'percent',
        // 		'options' => [
        // 			'percent'  => __( 'Percent', 'ryancv-plugin' ),
        // 			'dotted' => __( 'Dotted', 'ryancv-plugin' ),
        // 			'circles' => __( 'Circles', 'ryancv-plugin' ),
        // 			'list' => __( 'Knowledges', 'ryancv-plugin' ),
        // 		],
        // 	]
        // );

        $repeater = new Repeater();

        $repeater->add_control(
            'label',
            [
                'label'       => esc_html__('Label', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter label', 'watson'),
                'default' => esc_html__('Enter label', 'watson'),
            ]
        );

        $repeater->add_control(
            'progress',
            [
                'label'       => esc_html__('Progress (in %)', 'watson'),
                'type'        => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 99,
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ label }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .skills .subheading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .skills .subheading',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_styling',
            [
                'label' => esc_html__('Items', 'watson'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_label_color',
            [
                'label' => esc_html__('Label Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .skills .skill-item .progress-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_label_typography',
                'label' => esc_html__('Label Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .skills .skill-item .progress-title',
            ]
        );

        $this->add_control(
            'items_pvalue_color',
            [
                'label' => esc_html__('Progress Value Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .skill-item .progress .progress-value' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_pvalue_typography',
                'label' => esc_html__('Progress Value Typography:', 'watson'),
                'selector' => '{{WRAPPER}} .skill-item .progress .progress-value',
            ]
        );

        $this->add_control(
            'items_pline_color',
            [
                'label' => esc_html__('Progress Line Color', 'watson'),
                'type' => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .skill-item .progress .progress-bar' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .skill-item .progress .progress-bar:after' => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $this->add_inline_editing_attributes('title', 'basic');
?>
        <div class="skills">
            <?php if ($settings['title']) : ?>
                <h3 class="subheading">
                    <span <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></span>
                </h3>
            <?php endif; ?>

            <?php if ($settings['items']) :
                foreach ($settings['items'] as $index => $item) :
                    $item_label = $this->get_repeater_setting_key('label', 'items', $index);
                    $this->add_inline_editing_attributes($item_label, 'basic');
            ?>
                    <div class="skill-item">
                        <?php if ($item['label']) : ?>
                            <h4 class="progress-title">
                                <span <?php echo $this->get_render_attribute_string($item_label); ?>>
                                    <?php echo wp_kses_post($item['label']); ?>
                                </span>
                            </h4>
                        <?php endif; ?>

                        <?php if ($item['progress']) : ?>
                            <div class="progress">
                                <div class="progress-bar" style="width:<?php echo esc_attr($item['progress']); ?>%;">
                                    <div class="progress-value"><?php echo esc_attr($item['progress']); ?>%</div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
            <?php endforeach;
            endif; ?>
        </div>
    <?php

    }

    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    {
    ?>
        <# view.addInlineEditingAttributes( 'title' , 'basic' ); #>

            <div class="skills">
                <# if (settings.title) { #>
                    <h3 class="subheading">
                        <span {{{ view.getRenderAttributeString('title') }}}>{{{ settings.title }}}</span>
                    </h3>
                    <# } #>

                        <# if ( settings.items) { _.each( settings.items, function( item, index ) { var item_label=view.getRepeaterSettingKey( 'label' , 'items' , index ); view.addInlineEditingAttributes( item_label, 'basic' ); #>
                            <div class="skill-item">
                                <# if ( item.label ) { #>
                                    <h4 class="progress-title">
                                        <span {{{ view.getRenderAttributeString(item_label) }}}>
                                            {{{ item.label }}}
                                        </span>
                                    </h4>
                                <# } #>

                                <# if ( item.progress ) { #>
                                    <div class="progress">
                                        <div class="progress-bar" style="width:{{{ item.progress }}}%;">
                                            <div class="progress-value">{{{ item.progress }}}%</div>
                                        </div>
                                    </div>
                                <# } #>
                            </div>
                            <# }); }; #>
            </div>

    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Skills_Widget());
