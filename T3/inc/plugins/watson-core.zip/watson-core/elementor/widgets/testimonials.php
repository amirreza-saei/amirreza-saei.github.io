<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson Testimonials Widget.
 *
 * @since 1.0
 */
class Watson_Testimonials_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-testimonials';
    }

    public function get_title()
    {
        return esc_html__('Testimonials', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-comments';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'heading_tab',
            [
                'label' => esc_html__('Title', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Content', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'text', [
                'label'       => esc_html__('Text', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter text', 'watson'),
                'default'     => esc_html__('Enter text', 'watson'),
            ]
        );

        $repeater->add_control(
            'name', [
                'label'       => esc_html__('Name', 'watson'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__('Enter name', 'watson'),
                'default'     => esc_html__('Enter name', 'watson'),
            ]
        );

        $repeater->add_control(
            'role', [
                'label'       => esc_html__('Role', 'watson'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__('Enter role', 'watson'),
                'default'     => esc_html__('Enter role', 'watson'),
            ]
        );

        $repeater->add_control(
            'image', [
                'label' => esc_html__('Image', 'watson'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'settings_tab',
            [
                'label' => esc_html__('Settings', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'is_autoplay',
            [
                'label' => esc_html__('Autoplay', 'watson'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'watson'),
                'label_off' => esc_html__('No', 'watson'),
                'return_value' => 1,
                'default' => 0,
            ]
        );

        $this->add_control(
            'is_autoplaytime',
            [
                'label' => esc_html__('Autoplay Time', 'watson'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 50000,
                'step' => 100,
                'default' => 5000,
            ]
        );

        $this->add_control(
            'is_dots',
            [
                'label' => esc_html__('Dots', 'watson'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'watson'),
                'label_off' => esc_html__('No', 'watson'),
                'return_value' => 1,
                'default' => 0,
            ]
        );

        $this->add_control(
            'is_loop',
            [
                'label' => esc_html__('Loop', 'watson'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'watson'),
                'label_off' => esc_html__('No', 'watson'),
                'return_value' => 1,
                'default' => 0,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonials .subheading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .testimonials .subheading',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_styling',
            [
                'label'     => esc_html__('Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_bg_color',
            [
                'label'     => esc_html__('Background Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .testimonial-content' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .testimonial-item .testimonial-content::after' => 'border-top-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'items_text_color',
            [
                'label'     => esc_html__('Text Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .testimonial-content p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_text_typography',
                'label'     => esc_html__('Text Typography', 'watson'),
                'selector' => '{{WRAPPER}} .testimonial-item .testimonial-content p',
            ]
        );

        $this->add_control(
            'items_name_color',
            [
                'label'     => esc_html__('Name Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .testimonial-meta .meta-info h4' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_name_typography',
                'label'     => esc_html__('Name Typography', 'watson'),
                'selector' => '{{WRAPPER}} .testimonial-item .testimonial-meta .meta-info h4',
            ]
        );

        $this->add_control(
            'items_role_color',
            [
                'label'     => esc_html__('Role Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .testimonial-meta .meta-info p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_role_typography',
                'label'     => esc_html__('Role Typography', 'watson'),
                'selector' => '{{WRAPPER}} .testimonial-item .testimonial-meta .meta-info p',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $this->add_inline_editing_attributes('title', 'basic');
?>

        <div class="row testimonials">
            <div class="col-md-12">
                <?php if ($settings['title']) : ?>
                    <h3 class="subheading">
                        <span <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></span>
                    </h3>
                <?php endif; ?>
            </div>

            <?php if ($settings['items']) : ?>
                <div class="owl-carousel owl-theme" data-owl-loop="<?php echo esc_attr($settings['is_loop']); ?>" data-owl-autoplay="<?php echo esc_attr($settings['is_autoplay']); ?>" data-owl-speed="<?php echo esc_attr($settings['is_autoplaytime']); ?>" data-owl-dots="<?php echo esc_attr($settings['is_dots']); ?>">

                    <?php foreach ($settings['items'] as $index => $item) :
                        $item_text = $this->get_repeater_setting_key('text', 'items', $index);
                        $this->add_inline_editing_attributes($item_text, 'basic');

                        $item_name = $this->get_repeater_setting_key('name', 'items', $index);
                        $this->add_inline_editing_attributes($item_name, 'none');

                        $item_role = $this->get_repeater_setting_key('role', 'items', $index);
                        $this->add_inline_editing_attributes($item_role, 'none');
                    ?>
                        <!--Testimonail Item-->
                        <div class="testimonial-item">
                            <?php if ($item['text']) : ?>
                                <div class="testimonial-content">
                                    <p <?php echo $this->get_render_attribute_string($item_text); ?>>
                                        <?php echo wp_kses_post($item['text']); ?>
                                    </p>
                                </div>
                            <?php endif; ?>

                            <div class="testimonial-meta">
                                <?php if ($item['image']['id']) :
                                    $image = wp_get_attachment_image_url($item['image']['id'], 'watson_100x100');
                                ?>
                                    <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($item['name']); ?>">
                                <?php endif; ?>

                                <div class="meta-info">
                                    <?php if ($item['name']) : ?>
                                        <h4 <?php echo $this->get_render_attribute_string($item_name); ?>>
                                            <?php echo esc_html($item['name']); ?>
                                        </h4>
                                    <?php endif; ?>

                                    <?php if ($item['role']) : ?>
                                        <p <?php echo $this->get_render_attribute_string($item_role); ?>>
                                            <?php echo esc_html($item['role']); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php
        if (is_admin()) {
            echo "<script>$('.testimonials .owl-carousel').owlCarousel({
                loop: false,
                margin: 30,
                autoplay: false,
                smartSpeed: 500,
                responsiveClass: true,
                dots: false,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1,
                    },
                    800: {
                        items: 1,
                    },
                    1000: {
                        items: 2,
                    },
                },
            });</script>";
        }
    }

    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    {
        ?>
        <# view.addInlineEditingAttributes( 'title' , 'basic' ); #>

            <div class="row testimonials">
                <div class="col-md-12">
                    <# if ( settings.title ) { #>
                        <h3 class="subheading">
                            <span {{{ view.getRenderAttributeString('title') }}}>{{{ settings.title }}}</span>
                        </h3>
                        <# } #>
                </div>

                <# if ( settings.items ) { #>
                    <div class="owl-carousel owl-theme" data-owl-loop="{{{ settings.is_loop }}}" data-owl-autoplay="{{{ settings.is_autoplay }}}" data-owl-speed="{{{ settings.is_autoplaytime }}}" data-owl-dots="{{{ settings.is_dots }}}">

                        <# _.each( settings.items, function( item, index ) { var item_text=view.getRepeaterSettingKey( 'text' , 'items' , index ); view.addInlineEditingAttributes( item_text, 'basic' ); var item_name=view.getRepeaterSettingKey( 'name' , 'items' , index ); view.addInlineEditingAttributes( item_name, 'none' ); var item_role=view.getRepeaterSettingKey( 'role' , 'items' , index ); view.addInlineEditingAttributes( item_role, 'none' ); #>
                            <!--Testimonail Item-->
                            <div class="testimonial-item">
                                <# if ( item.text ) { #>
                                    <div class="testimonial-content">
                                        <p {{{ view.getRenderAttributeString( item_text ) }}}>
                                            {{{ item.text }}}
                                        </p>
                                    </div>
                                    <# } #>

                                        <div class="testimonial-meta">
                                            <# if ( item.image.url ) { #>
                                                <img src="{{{ item.image.url }}}" alt="{{{ item.name }}}">
                                                <# } #>

                                                    <div class="meta-info">
                                                        <# if ( item.name ) { #>
                                                            <h4 {{{ view.getRenderAttributeString( item_name ) }}}>
                                                                {{{ item.name }}}
                                                            </h4>
                                                            <# } #>

                                                                <# if ( item.role ) { #>
                                                                    <p {{{ view.getRenderAttributeString( item_role ) }}}>
                                                                        {{{ item.role }}}
                                                                    </p>
                                                                    <# } #>
                                                    </div>
                                        </div>
                            </div>
                            <# }); #>
                    </div>
                    <# } #>
            </div>

    <?php
        if (is_admin()) {
            echo "<script>$('.testimonials .owl-carousel').owlCarousel({
                loop: false,
                margin: 30,
                autoplay: false,
                smartSpeed: 500,
                responsiveClass: true,
                dots: false,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1,
                    },
                    800: {
                        items: 1,
                    },
                    1000: {
                        items: 2,
                    },
                },
            });</script>";
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Testimonials_Widget());
