<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson Services Widget.
 *
 * @since 1.0
 */

class Watson_Services_Widget extends Widget_Base
{

	public function get_name()
	{
		return 'watson-services';
	}

	public function get_title()
	{
		return esc_html__('Services', 'watson');
	}

	public function get_icon()
	{
		return 'eicon-tools';
	}

	public function get_categories()
	{
		return ['watson-category'];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls()
	{

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__('Title', 'watson'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__('Title', 'watson'),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__('Enter title', 'watson'),
				'default'     => esc_html__('Title', 'watson'),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__('Content', 'watson'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'icon', [
				'label'       => esc_html__('Icon', 'watson'),
				'type'        => Controls_Manager::ICONS,
            ]
        );

        $repeater->add_control(
            'name', [
				'label'       => esc_html__('Name', 'watson'),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__('Enter name', 'watson'),
				'default' => esc_html__('Enter name', 'watson'),
            ]
        );

        $repeater->add_control(
            'description', [
				'label'       => esc_html__('Description', 'watson'),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__('Enter description', 'watson'),
				'default' => esc_html__('Enter description', 'watson'),
            ]
        );

		$this->add_control(
			'items',
			[
				'label' => esc_html__('Items', 'watson'),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__('Title', 'watson'),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__('Color', 'watson'),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .services .subheading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .services .subheading',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__('Items', 'watson'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'items_icon_color',
			[
				'label' => esc_html__('Icon Color', 'watson'),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .services .service-item .icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'items_name_color',
			[
				'label' => esc_html__('Name Color', 'watson'),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .services .service-item .name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'items_name_typography',
				'label' => esc_html__('Name Typography:', 'watson'),
				'selector' => '{{WRAPPER}} .services .service-item .name',
			]
		);

		$this->add_control(
			'items_desc_color',
			[
				'label' => esc_html__('Description Color', 'watson'),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .services .service-item .desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'items_desc_typography',
				'label' => esc_html__('Description Typography:', 'watson'),
				'selector' => '{{WRAPPER}} .services .service-item .desc',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes('title', 'basic');
?>

		<div class="row services">
			<div class="col-md-12">
				<?php if ($settings['title']) : ?>
					<h3 class="subheading">
						<span <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></span>
					</h3>
				<?php endif; ?>
			</div>

			<?php if ($settings['items']) : ?>
				<?php foreach ($settings['items'] as $index => $item) :
					$item_name = $this->get_repeater_setting_key('name', 'items', $index);
					$this->add_inline_editing_attributes($item_name, 'basic');

					$item_desc = $this->get_repeater_setting_key('description', 'items', $index);
					$this->add_inline_editing_attributes($item_desc, 'advanced');
				?>
					<!--Service Item-->
					<div class="col-lg-3 col-sm-6">
						<div class="service-item">
							<?php if ($item['icon']) : ?>
								<div class="icon">
									<?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true']); ?>
								</div>
							<?php endif; ?>

							<?php if ($item['name']) : ?>
								<h4 class="name">
									<span <?php echo $this->get_render_attribute_string($item_name); ?>>
										<?php echo wp_kses_post($item['name']); ?>
									</span>
								</h4>
							<?php endif; ?>

							<?php if ($item['description']) : ?>
								<div class="desc">
									<div <?php echo $this->get_render_attribute_string($item_desc); ?>>
										<?php echo wp_kses_post($item['description']); ?>
									</div>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

		</div>

	<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template()
	{ ?>
		<# view.addInlineEditingAttributes( 'title' , 'basic' ); #>


			<div class="row services">
				<div class="col-md-12">
					<# if ( settings.title ) { #>
						<h3 class="subheading">
							<span {{{  view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
						</h3>
						<# } #>
				</div>
				<# if ( settings.items ) { #>
					<# _.each( settings.items, function( item, index ) { var iconHTML=elementor.helpers.renderIcon( view, item.icon, { 'aria-hidden' : true }, 'i' , 'object' ); var item_name=view.getRepeaterSettingKey( 'name' , 'items' , index ); view.addInlineEditingAttributes( item_name, 'basic' ); var item_desc=view.getRepeaterSettingKey( 'description' , 'items' , index ); view.addInlineEditingAttributes( item_desc, 'advanced' ); #>

						<!--Service Item-->
						<div class="col-lg-3 col-sm-6">
							<div class="service-item">
								<# if( item.icon ) { #>
									<div class="icon">
										{{{ iconHTML.value }}}
									</div>
									<# } #>

										<# if( item.name ) { #>
											<h4 class="name">
												<span {{{ view.getRenderAttributeString( item_name ) }}}>
													{{{ item.name }}}
												</span>
											</h4>
											<# } #>

												<# if( item.description ) { #>
													<div class="desc">
														<div {{{ view.getRenderAttributeString( item_desc ) }}}>
															{{{ item.description }}}
														</div>
													</div>
													<# } #>
							</div>
						</div>

						<# }); #>
							<# } #>

			</div>

	<?php }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Services_Widget());
