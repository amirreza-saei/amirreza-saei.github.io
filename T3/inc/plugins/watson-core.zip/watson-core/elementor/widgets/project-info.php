<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson About Me Widget.
 *
 * @since 1.0
 */
class Watson_Project_Info_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-project-info';
    }

    public function get_title()
    {
        return esc_html__('Project Info', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-table-of-contents';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {


        $this->start_controls_section(
            'project_info',
            [
                'label' => esc_html__('Project Information', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'info_title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'label',
            [
                'label'       => esc_html__('Label', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter label', 'watson'),
                'default' => esc_html__('Enter label', 'watson'),
            ]
        );

        $repeater->add_control(
            'value',
            [
                'label'       => esc_html__('Value', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter value', 'watson'),
                'default' => esc_html__('Enter value', 'watson'),
            ]
        );

        $this->add_control(
            'info_items',
            [
                'label' => esc_html__('Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ label }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'project_desc',
            [
                'label' => esc_html__('Project Description', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'desc_title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->add_control(
            'desc_content',
            [
                'label'       => esc_html__('Description', 'watson'),
                'type'        => Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__('Enter description',   'watson'),
                'default'     => esc_html__('Enter description', 'watson'),
            ]
        );

        $this->add_control(
            'link_text',
            [
                'label' => esc_html__('Project Link Text', 'watson'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Visit Live Version', 'watson'),
                'placeholder' => esc_html__('Enter the project link text', 'watson'),
            ]
        );

        $this->add_control(
			'website_link',
			[
				'label' => esc_html__( 'Project Link', 'watson' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-project-link.com', 'watson' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .project-intro .heading-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .project-intro .heading-title',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'items_styling',
            [
                'label'     => esc_html__('Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_label_color',
            [
                'label'     => esc_html__('Label Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .project-intro .project-info ul li .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_label_typography',
                'label'     => esc_html__('Label Typography', 'watson'),
                'selector' => '{{WRAPPER}} .project-intro .project-info ul li .title',
            ]
        );

        $this->add_control(
            'items_value_color',
            [
                'label'     => esc_html__('Value Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .project-intro .project-info ul li .value' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'items_value_typography',
                'label'     => esc_html__('Value Typography', 'watson'),
                'selector' => '{{WRAPPER}} .project-intro .project-info ul li .value',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'description_styling',
            [
                'label'     => esc_html__('Description', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .project-intro .text-box' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'selector' => '{{WRAPPER}} .project-intro .text-box',
            ]
        );

        $this->add_control(
            'link_color',
            [
                'label'     => esc_html__('Link Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .project-intro .project-link a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'link_typography',
                'selector' => '{{WRAPPER}} .project-intro .project-link a',
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $target = $settings['website_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['website_link']['nofollow'] ? ' rel="nofollow"' : '';
        $this->add_inline_editing_attributes('desc_title', 'basic');
        $this->add_inline_editing_attributes('desc_content', 'advanced');
        $this->add_inline_editing_attributes('info_title', 'basic');

?>

        <div class="row project-intro">

            <!--Project Info-->
            <div class="col-lg-4">
                <div class="project-info">
                    <?php if ($settings['info_title']) : ?>
                        <h3 class="heading-title mb-20">
                            <span <?php echo $this->get_render_attribute_string('info_title') ?>>
                                <?php echo wp_kses_post($settings['info_title']); ?>
                            </span>
                        </h3>
                    <?php endif; ?>

                    <?php if ($settings['info_items']) : ?>
                        <ul>
                            <?php foreach ($settings['info_items'] as $index => $item) :
                                $item_label = $this->get_repeater_setting_key('label', 'info_items', $index);
                                $this->add_inline_editing_attributes($item_label, 'basic');

                                $item_value = $this->get_repeater_setting_key('value', 'info_items', $index);
                                $this->add_inline_editing_attributes($item_value, 'basic');
                            ?>
                                <li>
                                    <span class="title">
                                        <span <?php echo $this->get_render_attribute_string($item_label); ?>>
                                            <?php echo wp_kses_post($item['label']); ?>
                                        </span>
                                    </span>

                                    <span class="value">
                                        <span <?php echo $this->get_render_attribute_string($item_value); ?>>
                                            <?php echo wp_kses_post($item['value']); ?>
                                        </span>
                                    </span>
                                </li>


                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <!-- <div class="resume-button mt-30">
                        <a class="btn-main" href="#">Download Resume</a>
                    </div> -->
                </div>
            </div>

            <!--Project Description-->
            <div class="col-lg-8">
                <?php if ($settings['desc_title']) : ?>
                    <h3 class="heading-title mb-20">
                        <span <?php echo $this->get_render_attribute_string('desc_title') ?>>
                            <?php echo wp_kses_post($settings['desc_title']); ?>
                        </span>
                    </h3>
                <?php endif; ?>

                <?php if ($settings['desc_content']) : ?>
                    <div class="text-box">
                        <div <?php echo $this->get_render_attribute_string('desc_content') ?>>
                            <?php echo wp_kses_post($settings['desc_content']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($settings['website_link']['url'] && $settings['link_text'] ) : ?>
                <div class="project-link">
                    <a href="<?php echo esc_url($settings['website_link']['url']); ?>" <?php echo $target . $nofollow; ?> ><?php echo esc_html($settings['link_text']); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </div>

    <?php
    }

    /**
     * Render widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function content_template()
    {
    ?>
        <# view.addInlineEditingAttributes( 'desc_title' , 'basic' ); view.addInlineEditingAttributes( 'desc_content' , 'advanced' ); view.addInlineEditingAttributes( 'info_title' , 'basic' ); #>

            <div class="row project-intro">


                <div class="col-lg-4">
                    <div class="project-info">
                        <# if ( settings.info_title ) { #>
                            <h3 class="heading-title mb-20">
                                <span {{{ view.getRenderAttributeString( 'info_title' ) }}}>
                                    {{{ settings.info_title }}}
                                </span>
                            </h3>
                            <# } #>

                                <# if ( settings.info_items ) { #>
                                    <ul>
                                        <# _.each( settings.info_items, function( item, index ) { var item_label=view.getRepeaterSettingKey( 'label' , 'info_items' , index ); view.addInlineEditingAttributes( item_label, 'basic' ); var item_value=view.getRepeaterSettingKey( 'value' , 'info_items' , index ); view.addInlineEditingAttributes( item_value, 'basic' ); #>
                                            <li>
                                                <span class="title">
                                                    <span {{{ view.getRenderAttributeString( item_label ) }}}>
                                                        {{{ item.label }}}
                                                    </span>
                                                </span>

                                                <span class="value">
                                                    <span {{{ view.getRenderAttributeString( item_value ) }}}>
                                                        {{{ item.value }}}
                                                    </span>
                                                </span>
                                            </li>


                                            <# }); #>
                                    </ul>
                                    <# } #>
                    </div>
                </div>

                <div class="col-lg-8">
                    <# if ( settings.desc_title ) { #>
                        <h3 class="heading-title mb-20">
                            <span>
                                {{{ settings.desc_title }}}
                            </span>
                        </h3>
                        <# } #>

                            <# if ( settings.desc_content ) { #>
                                <div class="text-box">
                                    <div {{{ view.getRenderAttributeString( 'desc_content' ) }}}>
                                        {{{ settings.desc_content }}}
                                    </div>
                                </div>
                                <# } #>
                <# if( settings.website_link.url && settings.link_text ) { #>
                <div class="project-link">
                    <a href="<# {{{ settings.website_link.url }}} #>" > {{{ settings.link_text }}}</a>
                </div>
                <# } #>

                </div>

            </div>

    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Project_Info_Widget());
