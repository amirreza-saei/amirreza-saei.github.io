<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson About Me Widget.
 *
 * @since 1.0
 */
class Watson_Hero_Slider_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-hero-slider';
    }

    public function get_title()
    {
        return esc_html__('Hero Slider', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-tv';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'full_name',
            [
                'label' => esc_html__('Name', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'first_name',
            [
                'label'       => esc_html__('First Name', 'watson'),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => esc_html__('Enter First Name', 'watson'),
                'default'     => esc_html__('PHILIP', 'watson'),
            ]
        );

        $this->add_control(
            'last_name',
            [
                'label'       => esc_html__('Last Name', 'watson'),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => esc_html__('Enter Last Name', 'watson'),
                'default'     => esc_html__('WATSON', 'watson'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content',
            [
                'label' => esc_html__('Content', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'static_text',
            [
                'label'       => esc_html__('Static Text', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Text', 'watson'),
            ]
        );

        $this->add_control(
            'is_animate',
            [
                'label' => __('Text Type', 'watson'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'animate',
                'options' => [
                    'animate'  => esc_html__('Animated Text', 'watson'),
                    'simple'  => esc_html__('Simple Text', 'watson'),
                ],
            ]
        );

        $this->add_control(
            'animation_type',
            [
                'label' => __('Select Animation', 'watson'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'clip',
                'options' => [
                    'clip'    => esc_html__('Clip', 'watson'),
                    'type'    => esc_html__('Type', 'watson'),
                    'rotate-1' => esc_html__('Rotate 1', 'watson'),
                    'rotate-2' => esc_html__('Rotate 2', 'watson'),
                    'rotate-3' => esc_html__('Rotate 3', 'watson'),
                    'loading-bar' => esc_html__('Loading Bar', 'watson'),
                    'slide'   => esc_html__('Slide', 'watson'),
                    'zoom'    => esc_html__('Zoom', 'watson'),
                    'scale'   => esc_html__('Scale', 'watson'),
                    'push'    => esc_html__('Push', 'watson'),
                ],
                'condition'   => [
                    'is_animate' => 'animate'
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'text', [
                'label'       => esc_html__('Enter Text', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Text', 'watson'),
                'default' => esc_html__('Text', 'watson'),
            ]
        );

        $this->add_control(
            'animated_texts',
            [
                'label' => esc_html__('Animated Texts', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ text }}}',
                'condition'   => [
                    'is_animate' => 'animate'
                ],
            ]
        );

        $this->add_control(
            'simple_text',
            [
                'label'       => esc_html__('Text', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Text', 'watson'),
                'condition'   => [
                    'is_animate' => 'simple'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider',
            [
                'label' => esc_html__('Slider', 'watson'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slide_speed',
            [
                'label'       => esc_html__('Slider Speed', 'watson'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 50000,
                'step' => 100,
                'default' => 3000,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'slide', [
                'label' => __('Choose Slider Image', 'watson'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'slides',
            [
                'label' => esc_html__('Image Slides', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'name_styling',
            [
                'label'     => esc_html__('Name', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'fname_color',
            [
                'label'     => esc_html__('First Name Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .banner-content .full-name .fname' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__('First Name Typography', 'watson'),
                'name'     => 'fname_typography',
                'selector' => '{{WRAPPER}} .banner-content .full-name .fname',
            ]
        );

        $this->add_control(
            'lname_color',
            [
                'label'     => esc_html__('Last Name Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .banner-content .full-name .lname' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__('Last Name Typography', 'watson'),
                'name'     => 'lname_typography',
                'selector' => '{{WRAPPER}} .banner-content .full-name .lname',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_styling',
            [
                'label'     => esc_html__('Content', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'static_text_color',
            [
                'label'     => esc_html__('Static Text Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .banner-content p .static-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__('Static Text Typography', 'watson'),
                'name'     => 'static_text_typography',
                'selector' => '{{WRAPPER}} .banner-content p .static-text',
            ]
        );

        $this->add_control(
            'animated_text_color',
            [
                'label'     => esc_html__('Animated Text Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .banner-content .cd-headline .cd-words-wrapper b' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__('Animated Text Typography', 'watson'),
                'name'     => 'animated_text_typography',
                'selector' => '{{WRAPPER}} .banner-content .cd-headline .cd-words-wrapper b',
            ]
        );

        $this->add_control(
            'simple_text_color',
            [
                'label'     => esc_html__('Simple Text Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .banner-content p .simple-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__('Simple Text Typography', 'watson'),
                'name'     => 'simple_text_typography',
                'selector' => '{{WRAPPER}} .banner-content p .simple-text',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $anim_type = $settings['animation_type'];
        $slide_speed = $settings['slide_speed'];

        $headline_class = '';
        $wrapper_class = '';

        if ($anim_type === 'rotate-2' || $anim_type === 'rotate-3' || $anim_type === 'scale') {

            $headline_class = 'letters';
        } else if ($anim_type === 'clip') {

            $headline_class = 'is-full-width';
        } else if ($anim_type === 'type') {

            $headline_class = 'letters';
            $wrapper_class = 'waiting';
        }
?>

        <!--Banner Section Start-->
        <div class="banner">

            <?php if ($settings['slides']) : ?>
                <div class="banner-slider">
                    <div id="slides" data-speed="<?php echo esc_attr($slide_speed); ?>">
                        <div class="slides-container">
                            <?php foreach ($settings['slides'] as $item) : ?>
                                <img src="<?php echo esc_url($item['slide']['url']); ?>" alt="<?php esc_attr_e('Slide Speed', 'watson') ?>">
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="banner-content">
                <!--Banner Text-->
                <h1 class="full-name">
                    <?php if ($settings['first_name']) : ?>
                        <span class="fname">
                            <?php echo wp_kses_post($settings['first_name']); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($settings['last_name']) : ?>
                        <span class="lname">
                            <?php echo wp_kses_post($settings['last_name']); ?>
                        </span>
                    <?php endif; ?>
                </h1>

                <?php if ($settings['is_animate'] == 'animate') : ?>
                    <!--Animated Text-->

                    <p class="cd-headline <?php echo esc_attr($anim_type); ?> <?php echo esc_attr($headline_class); ?>">

                        <?php if ($settings['static_text']) : ?>
                            <span class="static-text"><?php echo wp_kses_post($settings['static_text']); ?></span>
                        <?php endif; ?>

                        <?php if ($settings['animated_texts']) : ?>
                            <span class="cd-words-wrapper <?php echo esc_attr($wrapper_class); ?>">
                                <?php foreach ($settings['animated_texts'] as $index => $item) : ?>
                                    <b class="<?php if ($index == 0) echo 'is-visible'; ?>"><?php echo wp_kses_post($item['text']); ?></b>
                                <?php endforeach; ?>
                            </span>
                        <?php endif; ?>

                    </p>

                <?php else : ?>
                    <p>
                        <?php if ($settings['static_text']) : ?>
                            <span class="static-text">
                                <?php echo wp_kses_post($settings['static_text']); ?>
                            </span>
                        <?php endif; ?>
                        <?php if ($settings['simple_text']) : ?>
                            <b class="simple-text">
                                <?php echo wp_kses_post($settings['simple_text']); ?>
                            </b>
                        <?php endif; ?>
                    </p>
                <?php endif; ?>

            </div>
        </div>

        <!--Banner Section End-->


        <script>
            //Super Slider
            jQuery(function() {
                var speed = $('#slides').data('speed');
                jQuery('#slides').superslides({
                    animation: 'fade',
                    play: speed,
                });
            });
        </script>


<?php

    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Hero_Slider_Widget());
