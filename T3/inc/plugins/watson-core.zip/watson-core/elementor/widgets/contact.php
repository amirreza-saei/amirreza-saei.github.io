<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Watson Contact Widget.
 *
 * @since 1.0
 */

class Watson_Contact_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'watson-contact';
    }

    public function get_title()
    {
        return esc_html__('Contact', 'watson');
    }

    public function get_icon()
    {
        return 'eicon-mail';
    }

    public function get_categories()
    {
        return ['watson-category'];
    }

    /**
     * Register widget controls.
     *
     * @since 1.0
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'heading_tab',
            [
                'label' => esc_html__('Title', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__('Title', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter title', 'watson'),
                'default'     => esc_html__('Title', 'watson'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'contact_form_tab',
            [
                'label' => esc_html__('Contact Form', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'contact_form',
            [
                'label' => esc_html__('Select CF7 Form', 'watson'),
                'type' => Controls_Manager::SELECT,
                'default' => 1,
                'options' => $this->get_contact_form_list(),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'contact_info_tab',
            [
                'label' => esc_html__('Contact Info', 'watson'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'info_icon',
            [
                'label'       => esc_html__('Icon', 'watson'),
                'type'        => Controls_Manager::ICONS,
            ]
        );

        $repeater->add_control(
            'info_text',
            [
                'label'       => esc_html__('Text', 'watson'),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__('Enter Text', 'watson'),
                'default' => esc_html__('Enter Text', 'watson'),
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Info Items', 'watson'),
                'type' => Controls_Manager::REPEATER,
                'prevent_empty' => false,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ info_text }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_styling',
            [
                'label'     => esc_html__('Title', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Color', 'watson'),
                'type'      => Controls_Manager::COLOR,
                'default'    => '',
                'selectors' => [
                    '{{WRAPPER}} .contact .subheading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .contact .subheading',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'info_styling',
            [
                'label'     => esc_html__('Contact Items', 'watson'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'items_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'watson' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .contact-info .info-item .icon' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'items_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'watson' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .contact-info .info-item h5' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'items_text_typography',
				'label'     => esc_html__( 'Text Typography', 'watson' ),
				'selector' => '{{WRAPPER}} .contact-info .info-item h5',
			]
		);

        $this->end_controls_section();
    }

    /**
     * Render Contact Form List.
     *
     * @since 1.0
     */
    protected function get_contact_form_list()
    {
        $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);

        $cf7_form_list = [];

        if ($cf7_forms = get_posts($args)) {
            foreach ($cf7_forms as $form) {
                (int)$cf7_form_list[$form->ID] = $form->post_title;
            }
        } else {
            (int)$cf7_form_list['0'] = esc_html__('No Contact Form 7 found', 'watson');
        }
        return $cf7_form_list;
    }

    /**
     * Render widget output on the frontend.
     *
     * @since 1.0
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $this->add_inline_editing_attributes('title', 'basic');
        $count = count($settings['items']);
        if( $count === 1 ) {
            $item_class = 'col-md-12';
        } else if ( $count === 2  ) {
            $item_class = 'col-md-6';
        } else if ( $count >= 3 ) {
            $item_class = 'col-md-4';
        }
?>

        <div class="contact">
            <div class="row">
                <div class="col-lg-8  offset-lg-2">
                    <?php if ($settings['title']) : ?>
                        <h3 class="subheading">
                            <span <?php echo $this->get_render_attribute_string('title'); ?>><?php echo wp_kses_post($settings['title']); ?></span>
                        </h3>
                    <?php endif; ?>

                    <!--Form Start-->
                    <div class="contact-form">
                        <?php echo do_shortcode('[contact-form-7 id="' . esc_attr($settings['contact_form']) . '"]'); ?>
                    </div>
                    <!--Form End-->

                </div>
            </div>

            <?php if ($settings['items']) : ?>
                <div class="row contact-info mt-70">
                    <?php foreach ($settings['items'] as $index => $item) :
                        $item_text = $this->get_repeater_setting_key('info_text', 'items', $index);
                        $this->add_inline_editing_attributes($item_text, 'basic');
                    ?>

                        <div class="<?php echo esc_attr( $item_class ); ?> info-item">
                            <?php if ($item['info_icon']) : ?>
                                <span class="icon">
                                    <?php \Elementor\Icons_Manager::render_icon($item['info_icon'], ['aria-hidden' => 'true']); ?>
                                </span>
                            <?php endif; ?>

                            <?php if ($item['info_text']) : ?>
                                <h5 <?php echo $this->get_render_attribute_string($item_text); ?>>
                                    <?php echo wp_kses_post($item['info_text']); ?>
                                </h5>
                            <?php endif; ?>
                        </div>

                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>


<?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Watson_Contact_Widget());
