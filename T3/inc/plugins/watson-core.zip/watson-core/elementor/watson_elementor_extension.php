<?php 
/**
 *  Watson Elementor Extension
 *
 * @package watson
 * @since 1.0
 */

// We check if the Elementor plugin has been installed / activated.

if( !in_array( 'elementor/elementor.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;

class Watson_Elementor_Extension {
 
	private static $instance = null;

	/**
	 * @since 1.0
	 */
	public static function get_instance() {
	    if ( ! self::$instance )
	       self::$instance = new self;
	    return self::$instance;
	}

	/**
	 * @since 1.0
	 */
	public function init(){
		add_action( 'elementor/widgets/register', array( $this, 'watson_elementor_register_widgets' ) );
		
		// add_action('elementor/frontend/after_register_styles', array($this, 'watson_elementor_frontend_styles'), 10);
		
		// add_action('elementor/frontend/after_register_scripts', array($this, 'watson_elementor_frontend_scripts'), 10);

		add_action( 'elementor/elements/categories_registered', array( $this, 'watson_elementor_widgets_category' ) );

		require_once(__DIR__ . '/watson_icon_setup.php');
	}

	/**
	 * @since 1.0
	 */
	public function watson_elementor_register_widgets() {
		//Require all PHP files in the /elementor/widgets directory
		// foreach( glob( plugin_dir_path( __FILE__ ) . "widgets/*.php" ) as $file ) {
		foreach( glob( plugin_dir_path( __FILE__ ) . "widgets/*.php" ) as $file ) {
		    require $file; 
		} 
	}

	/**
	 * @since 1.0
	 */
	public function watson_elementor_widgets_category( $elements_manager ) {
		$elements_manager->add_category(
			'watson-category',
			[
				'title' => esc_html__( 'Watson Theme', 'watson' ),
				'icon' => 'fa fa-plug',
			]
		);  

	}
}
 
Watson_Elementor_Extension::get_instance()->init();
