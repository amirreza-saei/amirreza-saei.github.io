<?php
/*
Plugin Name: Watson Core
Plugin URI: https://themeforest.net/user/cosmos-themes
Description: Core Plugin for Watson Wordpress Theme
Author: Cosmos-Themes
Author URI: https://themeforest.net/user/cosmos-themes
Version: 2.0.0
Text Domain: watson
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

include_once('elementor/watson_elementor_extension.php');

include_once('inc/custom-post-type-config.php');

include_once ('inc/metabox-config.php');

/* Load plugin text-domain */
function ct_watson_load_textdomain() {
	load_plugin_textdomain( 'watson', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'ct_watson_load_textdomain' );
