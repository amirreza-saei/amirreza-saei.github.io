"use strict";

var $ = jQuery;
$(function(){
    $( 'input[id ^=watson_portfolio_option_portfolio_type]' ).each(function() {

        var itemValue = $(this).val();

        if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'video' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_video_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        else if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'music' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_music_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        
        else if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'link' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_link_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        else {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
        }
    });


    $('input[id^=watson_portfolio_option_portfolio_type]').on('click', function() {

        if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'video' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_video_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        else if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'music' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_music_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        else if ( $('input[id ^="watson_portfolio_option_portfolio_type"]:checked').val() === 'link' )  {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
            $('input[id="watson_portfolio_option_radio_button_link_url" ]').closest('.cmb-type-text-url').removeClass('metabox-hide');
        }
        else {
            $('input[id^="watson_portfolio_option_radio_button" ]').closest('.cmb-type-text-url').addClass('metabox-hide');
        }
    });
});