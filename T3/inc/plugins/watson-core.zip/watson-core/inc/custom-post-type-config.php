<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Register custom post types
if ( ! function_exists( 'ct_watson_custom_types' ) ){

    function ct_watson_custom_types() {

        $custom_slug = null;
		if( function_exists( 'watson_get_theme_options' ) ){
			$watson_custom_slug_option = watson_get_theme_options( 'ct_watson_portfolio_custom_slug' );
			if( !empty( $watson_custom_slug_option ) ){
				
				$custom_slug = $watson_custom_slug_option;
			}
		}
		
        register_post_type(
            'portfolio',
            array(
                'labels' => array(
                    'name' => esc_html__('Portfolio', 'watson'),
                    'singular_name' => esc_html__('Portfolio', 'watson'),
                    'all_items' => esc_html__('Portfolio Items', 'watson'),
                    'add_new' => esc_html__( 'Add New', 'watson' ),
                    'add_new_item' => esc_html__( 'Add New Portfolio Item', 'watson' ),
                    'edit_item' => esc_html__( 'Edit Portfolio Item', 'watson' ),
                    'new_item' => esc_html__( 'New Portfolio Item', 'watson' ),
                    'view_item' => esc_html__( 'View Portfolio Item', 'watson' ),
                    'search_items' => esc_html__( 'Search Portfolio Items', 'watson' ),
                    'not_found' => esc_html__( 'No portfolio items found', 'watson' ),
                    'not_found_in_trash' => esc_html__( 'No portfolio items found in Trash', 'watson' ),
                    'menu_name' => esc_html__( 'Portfolio', 'watson' ),
                ),
                'rewrite' => array('slug' => $custom_slug, 'with_front' => false),
                'description' => 'Add your Portfolio',
                'menu_icon' =>  'dashicons-portfolio',
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'supports' => array('title', 'editor', 'revisions', 'thumbnail', 'author', 'page-attributes'),
            )
        );

		register_taxonomy( 	'portfolio_category', 
                            'portfolio', 
                            array(
                                'hierarchical' => true, 
                                'label' => esc_html__('Categories', 'watson'), 
                                'query_var' => true, 
                                'show_in_rest' => true,
                                'rewrite' => true
                        ));
    }

}
add_action('init', 'ct_watson_custom_types');


// refresh rewrite rules for custom portfolio slugs
if ( ! function_exists( 'ct_watson_activation_hook' ) ){

    function ct_watson_activation_hook() {

		ct_watson_custom_types();
		
        flush_rewrite_rules();
    }
}
register_activation_hook( __FILE__, 'ct_watson_activation_hook' );



?>
