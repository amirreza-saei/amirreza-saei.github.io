<?php
/**
 * Use to define meta boxes for post types
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} 

if ( !function_exists( 'watson_portfolio_metaboxes' ) ) {
    
    function watson_portfolio_metaboxes() {

        $prefix = 'watson_portfolio_option_';

        $portfolio_options = new_cmb2_box( array(
            'id' => $prefix . 'portfolio_metabox',
            'title' => esc_html__( 'Portfolio Item Options', 'watson' ),
            'object_types' => array( 'portfolio' )
        ) );

        $portfolio_options->add_field(array(
            'id'               => $prefix . 'portfolio_type',
            'name'             => esc_html__('Portfolio Preview Type', 'watson'),
            'desc'             => esc_html__('Select the portfolio preview type to be shown as a lightbox popup.', 'watson'),
            'type'             => 'radio',
            'options'          => array(
                'image' => esc_html__('Image', 'watson'),
                'video'   => esc_html__('Video', 'watson'),
                'music'   => esc_html__('Music', 'watson'),
                'ajax'   => esc_html__('Content', 'watson'),
                'link'   => esc_html__('Link', 'watson'),
            ),
            'default' => 'image',
        ));

        $portfolio_options->add_field(array(
            'id' => $prefix . 'radio_button_video_url',
            'class' => 'custom_box_watson',
            'name' => esc_html__('Video URL (vimeo or youtube)', 'watson'),
            'type' => 'text_url',
            'protocols' => array( 'http', 'https' ),
        ));

        $portfolio_options->add_field(array(
            'id' => $prefix . 'radio_button_music_url',
            'name' => esc_html__('Music URL (soundcloud)', 'watson'),
            'type' => 'text_url',
            'protocols' => array( 'http', 'https' ),
        ));

        $portfolio_options->add_field(array(
            'id' => $prefix . 'radio_button_link_url',
            'name' => esc_html__('Link URL', 'watson'),
            'type' => 'text_url',
            'protocols' => array( 'http', 'https' ),
            'width' => 200,
        ));
    }
}

add_action('cmb2_admin_init', 'watson_portfolio_metaboxes');

function watson_enqueue_custom_cmb2_script() {
    global $post_type;
    if ( $post_type === 'portfolio' ) {
        wp_enqueue_style('admin-metabox-style', plugin_dir_url( __FILE__ ) . 'assets/css/admin-metabox-style.css');

        wp_enqueue_script('admin-metabox-script', plugin_dir_url( __FILE__ ) . 'assets/js/admin-metabox-script.js', 'jquery', false, true);
    }
}

add_action( 'admin_enqueue_scripts', 'watson_enqueue_custom_cmb2_script' );
